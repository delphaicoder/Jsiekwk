# Liquid Folder — Tweak jailbreak iOS/iPadOS 15–16

Tweak SpringBoard: bo vien trang mo va hieu ung "kinh mo" (liquid glass, kieu iOS 26)
cho cac folder tren man hinh chinh. Co muc Cai dat rieng de:
- Bat/tat hieu ung
- Chon muc chat luong render: **Tat / Nhe / Cao** — de toi uu hieu nang, giam RAM.

## Cau truc project
```
LiquidFolder/
├── control                         # thong tin package (Sileo/dpkg)
├── Makefile                        # build tweak chinh
├── LiquidFolder.plist               # chi inject vao SpringBoard
├── Tweak.xm                         # logic ve vien + kinh mo
├── layout/Library/PreferenceLoader/Preferences/LiquidFolderEntry.plist
│                                     # dua muc "Liquid Folder" vao app Cai dat
└── LiquidFolderPrefs/                # subproject: man hinh Cai dat
    ├── Makefile
    ├── LiquidFolderPrefsController.h/.m
    └── Resources/{Info,Root}.plist
```

## Yeu cau de BUILD (tren may cua ban, khong phai tren iPhone)
1. macOS hoac Linux (hoac container Docker) da cai **Theos**:
   https://github.com/theos/theos/wiki/Installation
2. Theos SDK cho iOS (khuyen nghi iOS 15.5 SDK hoac tuong duong) da duoc dat trong
   `$THEOS/sdks/`.
3. `ldid` hoac cong cu ky (Theos tu cai kem).

## Build package
```bash
cd LiquidFolder
export THEOS=/path/to/theos      # neu chua set san
make clean
make package FINALPACKAGE=1
```
- Neu jailbreak muc tieu la **rootless** (Dopamine, palera1n rootless, XinaA15...):
  ```bash
  make package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME=rootless
  ```
- Neu la **rootful** (checkra1n, unc0ver, taurine...): build lenh mac dinh o tren la du.

File `.deb` se nam trong thu muc `packages/`.

## Cai qua Sileo (khong dung Cydia)
Cach 1 — copy thang vao may:
1. Dung Filza/SSH copy file `.deb` vao iPhone, vi du `/var/mobile/Documents/`.
2. Mo Sileo → tab **Cai dat** (hoac bieu tuong dau...) → **Cai dat tu file** (Install from
   .deb) neu ban co plugin "Sileo Debinstall", hoac dung Filza va chon "Open in Sileo".

Cach 2 — tu build script CI hoac repo rieng:
1. Dua file `.deb` len repo Sileo (vi du dung `dpkg-scanpackages` de tao repo APT don gian).
2. Them repo do vao Sileo → Nguon → tim goi "Liquid Folder" → Cai dat.

Sau khi cai, Sileo/postinst se tu **respring** (khoi dong lai SpringBoard) — nhu duoc
khai bao trong `after-install::` cua Makefile.

## Su dung
- Mo app **Cai dat** → cuon xuong tim muc **Liquid Folder**.
- Bat "Bat hieu ung", chon muc "Chat luong render":
  - **Tat**: giu icon folder nguyen goc, khong ton hieu nang.
  - **Nhe**: chi phu mot lop mau trang trong suot tinh (khong dung blur that) → gan nhu
    khong ton them RAM/GPU, phu hop may cu hoac muon tiet kiem pin.
  - **Cao**: dung `UIVisualEffectView` blur that (Ultra Thin Material) → dep, giong
    "liquid glass" that su, nhung ton GPU/RAM hon mot chut vi SpringBoard phai render
    blur song cho tung folder tren man hinh.
- Nhan **"Respring ngay"** de ap dung ngay lap tuc.

## Luu y ky thuat quan trong
- Tweak hook class private `SBIconView`/`SBFolderIcon` cua SpringBoard. Ten class nay
  **on dinh** qua nhieu ban iOS 15–16, nhung ten **ivar/property** de lay UIView ve icon
  (`iconImageView`) co the khac nhau đôi chút giua cac phien ban iOS phu (15.x/16.x).
  Code trong `Tweak.xm` (`LF_FindIconImageView`) da thu lan luot vai ten pho bien va bao
  ve bang `@try/@catch` de khong lam crash SpringBoard neu khong tim thay — nhung neu
  hieu ung khong hien ra dung vi tri o mot ban iOS cu the, ban nen dung class-dump-ios /
  Cycript / Flexdump ngay tren may that (o ban iOS do) de kiem tra dung ten ivar/property
  va sua lai `candidateKeys` trong `LF_FindIconImageView`.
- Vi day la hook UI runtime cua SpringBoard, minh khong co moi truong iOS that de bien
  dich va test truc tiep — code duoc viet theo dung quy uoc Theos/Logos va cac pattern
  pho bien trong cong dong tweak jailbreak, nhung ban nen test tren thiet bi that (hoac
  may ao neu co) truoc khi dung lau dai.

#import "LiquidFolderPrefsController.h"

@implementation LiquidFolderPrefsController

- (NSArray *)specifiers {
    if (!_specifiers) {
        _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    }
    return _specifiers;
}

- (void)lf_respring {
    // Ghi thong bao Darwin de tweak co the phan ung ngay, roi respring de doi trien khai
    // hoan toan (folder icon can duoc ve lai tu dau).
    CFNotificationCenterPostNotification(
        CFNotificationCenterGetDarwinNotifyCenter(),
        CFSTR("com.yourname.liquidfolder/prefschanged"),
        NULL, NULL, YES
    );
    system("killall -9 SpringBoard");
}

@end

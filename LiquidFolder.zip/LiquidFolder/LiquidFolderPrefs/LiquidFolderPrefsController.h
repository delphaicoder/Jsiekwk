#import <Preferences/PSListController.h>

@interface LiquidFolderPrefsController : PSListController
- (NSArray *)specifiers;
- (void)lf_respring;
@end

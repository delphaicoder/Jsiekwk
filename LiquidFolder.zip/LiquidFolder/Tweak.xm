// LiquidFolder — Tweak.xm
// Ve vien trang mo (~1pt, alpha thap) + lop "kinh mo" (liquid glass) phia sau icon cua Folder
// tren man hinh chinh. Co 3 muc chat luong de tiet kiem RAM/hieu nang:
//   0 = Tat  (khong doi gi, giu nguyen icon goc)
//   1 = Nhe  (mot lop mau trong suot tinh, KHONG dung UIVisualEffectView -> re nhat)
//   2 = Cao  (dung UIVisualEffectView blur that -> dep nhat, ton GPU/RAM hon)

#import <UIKit/UIKit.h>
#import <objc/runtime.h>

static NSString *const kPrefsPath = @"/var/mobile/Library/Preferences/com.yourname.liquidfolder.plist";
static CFStringRef const kDarwinNotify = CFSTR("com.yourname.liquidfolder/prefschanged");

static BOOL gEnabled = YES;
static NSInteger gQuality = 1; // 0 tat, 1 nhe, 2 cao

static void LF_LoadPrefs(void) {
    NSDictionary *prefs = [NSDictionary dictionaryWithContentsOfFile:kPrefsPath];
    if (!prefs) {
        gEnabled = YES;
        gQuality = 1;
        return;
    }
    gEnabled = prefs[@"Enabled"] ? [prefs[@"Enabled"] boolValue] : YES;
    gQuality = prefs[@"Quality"] ? [prefs[@"Quality"] integerValue] : 1;
}

static void LF_NotifyCallback(CFNotificationCenterRef center, void *observer,
                               CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    LF_LoadPrefs();
}

// Tim UIView con dung de ve icon (ten ivar/property nay co the khac nhau giua cac ban iOS,
// nen thu lan luot mot vai ten pho bien thay vi goi valueForKey: truc tiep (de tranh crash
// SpringBoard neu key khong ton tai).
static UIView *LF_FindIconImageView(UIView *iconView) {
    static NSArray<NSString *> *candidateKeys;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        candidateKeys = @[@"iconImageView", @"_iconImageView", @"imageView"];
    });
    for (NSString *key in candidateKeys) {
        @try {
            id value = [iconView valueForKey:key];
            if ([value isKindOfClass:[UIView class]]) {
                return (UIView *)value;
            }
        } @catch (__unused NSException *e) {
            // key khong ton tai tren ban iOS nay, thu key tiep theo
            continue;
        }
    }
    return iconView; // fallback: ve len chinh icon view
}

%hook SBIconView

%property (nonatomic, retain) UIView *lf_glassView;
%property (nonatomic, retain) CALayer *lf_borderLayer;

- (void)layoutSubviews {
    %orig;

    id icon = nil;
    @try { icon = [self valueForKey:@"icon"]; } @catch (__unused NSException *e) {}
    Class folderIconClass = NSClassFromString(@"SBFolderIcon");
    BOOL isFolder = folderIconClass && [icon isKindOfClass:folderIconClass];

    if (!gEnabled || gQuality == 0 || !isFolder) {
        if (self.lf_glassView) {
            [self.lf_glassView removeFromSuperview];
            self.lf_glassView = nil;
        }
        if (self.lf_borderLayer) {
            [self.lf_borderLayer removeFromSuperlayer];
            self.lf_borderLayer = nil;
        }
        return;
    }

    UIView *imageView = LF_FindIconImageView(self);
    CGRect bounds = imageView.bounds;
    if (bounds.size.width <= 0 || bounds.size.height <= 0) return;

    CGFloat corner = bounds.size.width * 0.24; // ti le bo goc gan giong folder iOS

    // --- Lop kinh mo ---
    if (!self.lf_glassView) {
        UIView *glass;
        if (gQuality >= 2) {
            UIBlurEffect *effect;
            if (@available(iOS 13.0, *)) {
                effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemUltraThinMaterial];
            } else {
                effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleLight];
            }
            UIVisualEffectView *v = [[UIVisualEffectView alloc] initWithEffect:effect];
            v.alpha = 0.55;
            glass = v;
        } else {
            // Muc "Nhe": khong dung blur that, chi 1 view mau trang trong suot -> re, it RAM
            UIView *v = [[UIView alloc] initWithFrame:bounds];
            v.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.12];
            glass = v;
        }
        glass.userInteractionEnabled = NO;
        glass.layer.cornerRadius = corner;
        glass.layer.masksToBounds = YES;
        [imageView insertSubview:glass atIndex:0];
        self.lf_glassView = glass;
    }
    self.lf_glassView.frame = bounds;
    self.lf_glassView.layer.cornerRadius = corner;

    // --- Vien trang mo ---
    if (!self.lf_borderLayer) {
        CALayer *border = [CALayer layer];
        border.borderColor = [UIColor colorWithWhite:1.0 alpha:0.5].CGColor;
        border.borderWidth = 1.0;
        [imageView.layer addSublayer:border];
        self.lf_borderLayer = border;
    }
    self.lf_borderLayer.frame = bounds;
    self.lf_borderLayer.cornerRadius = corner;
}

%end

%ctor {
    LF_LoadPrefs();
    CFNotificationCenterAddObserver(
        CFNotificationCenterGetDarwinNotifyCenter(),
        NULL,
        LF_NotifyCallback,
        kDarwinNotify,
        NULL,
        CFNotificationSuspensionBehaviorCoalesce
    );
}
